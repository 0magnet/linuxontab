<?php
// LinuxOnTab PHP demo — served by `php -S` inside the wasm guest.
$counterFile = '/var/lib/php/counter.txt';
$count = (int)@file_get_contents($counterFile) + 1;
@file_put_contents($counterFile, (string)$count, LOCK_EX);

$name = isset($_POST['name']) ? trim((string)$_POST['name']) : '';
$h = fn($s) => htmlspecialchars((string)$s, ENT_QUOTES);

$db = null;
if (class_exists('PDO') && in_array('sqlite', PDO::getAvailableDrivers(), true)) {
    $db = new PDO('sqlite:/var/lib/php/demo.sqlite');
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $db->exec('CREATE TABLE IF NOT EXISTS guests (id INTEGER PRIMARY KEY, name TEXT, at TEXT)');
    if ($name !== '') {
        $st = $db->prepare('INSERT INTO guests (name, at) VALUES (?, ?)');
        $st->execute([$name, date('c')]);
    }
}
$guests = $db ? $db->query('SELECT name, at FROM guests ORDER BY id DESC LIMIT 10')->fetchAll(PDO::FETCH_ASSOC) : [];
?><!doctype html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>PHP on LinuxOnTab</title>
<style>
 :root { color-scheme: light dark; --bg:#f6f7fb; --fg:#1d2330; --card:#fff; --mut:#5b6476; --acc:#777bb4; }
 @media (prefers-color-scheme: dark) { :root { --bg:#141821; --fg:#e7e9ef; --card:#1d2230; --mut:#9aa3b5; } }
 body { margin:0; font:15px/1.5 system-ui, sans-serif; background:var(--bg); color:var(--fg); }
 main { max-width:720px; margin:0 auto; padding:24px 16px; }
 h1 { margin:0 0 4px; font-size:24px; } h1 span { color:var(--acc); }
 .card { background:var(--card); border-radius:10px; padding:16px; margin:14px 0; box-shadow:0 1px 3px rgba(0,0,0,.08); }
 table { border-collapse:collapse; width:100%; } td { padding:4px 8px; border-bottom:1px solid rgba(127,127,127,.2); }
 td:first-child { color:var(--mut); width:40%; }
 input, button { font:inherit; padding:6px 10px; border-radius:6px; border:1px solid rgba(127,127,127,.4); }
 button { background:var(--acc); color:#fff; border:0; }
 small { color:var(--mut); }
</style></head><body><main>
<h1><span>PHP</span> <?= $h(PHP_VERSION) ?> on LinuxOnTab</h1>
<small>Rendered by <code>php -S</code> running in a wasm32 Linux guest in your browser tab.</small>
<div class="card"><table>
<tr><td>PHP version</td><td><?= $h(PHP_VERSION) ?> (<?= $h(PHP_SAPI) ?>, <?= $h(php_uname('s') . ' ' . php_uname('r') . ' ' . php_uname('m')) ?>)</td></tr>
<tr><td>Zend Engine</td><td><?= $h(zend_version()) ?></td></tr>
<tr><td>Server time</td><td><?= $h(date('Y-m-d H:i:s T')) ?></td></tr>
<tr><td>Visits (counter file)</td><td><?= $count ?></td></tr>
<tr><td>Memory</td><td><?= $h(number_format(memory_get_usage() / 1024, 1)) ?> KiB (peak <?= $h(number_format(memory_get_peak_usage() / 1024, 1)) ?> KiB)</td></tr>
<tr><td>Extensions</td><td><?= $h(implode(', ', get_loaded_extensions())) ?></td></tr>
</table></div>
<div class="card">
<form method="post"><label>Sign the guest book: <input name="name" maxlength="40" required></label> <button>Sign</button></form>
<?php if ($name !== ''): ?><p>Hello, <b><?= $h($name) ?></b>!</p><?php endif; ?>
<?php if ($guests): ?><table><?php foreach ($guests as $g): ?>
<tr><td><?= $h($g['at']) ?></td><td><?= $h($g['name']) ?></td></tr>
<?php endforeach; ?></table><?php elseif (!$db): ?><small>(pdo_sqlite not available)</small><?php endif; ?>
</div>
</main></body></html>
